import os
import shutil
import subprocess
from services.rm_from_path import remove_path_from_env

def uninstall(INSTALL_DIR, package_name):
    remove_path = os.path.join(INSTALL_DIR, package_name)
    if os.path.exists(remove_path):
        print(f"Removing {package_name}...")
        shutil.rmtree(remove_path)

        remove_path_from_env(remove_path)
        print("Uninstallation completed.")

    else:
        print(f"{package_name} is not installed.")


