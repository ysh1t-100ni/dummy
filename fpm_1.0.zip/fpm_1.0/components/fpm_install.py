import os
from services.download_package import download_package

def install(arch, INSTALL_DIR, package_json, file_name, version):
    print(f"Detected architecture: {arch}")
    PACKAGE_INSTALL_DIRECTORY = os.path.join(INSTALL_DIR, file_name)
    if not os.path.exists(PACKAGE_INSTALL_DIRECTORY):
        os.makedirs(PACKAGE_INSTALL_DIRECTORY)
    download_package(PACKAGE_INSTALL_DIRECTORY, arch, package_json, version)
    # add_to_path()
    print("Installation completed. You can now use node from any terminal!")