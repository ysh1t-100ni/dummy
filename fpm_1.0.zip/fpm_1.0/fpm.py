import os
import sys
from utils.github import get_github_file_content
from utils.fetch_system_details import get_architecture
from components.fpm_install import install
from components.fpm_uninstall import uninstall

def main():
    repo = "Main"
    access_token = "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"  # Replace with your actual token (optional for public repos)
    architecuture = get_architecture()
    INSTALL_DIR = os.path.expanduser("~\\fpm")



    if len(sys.argv) != 3:
        print("Usage: python wpm.py install|uninstall <package_name>")
        sys.exit(1)
    
    action = sys.argv[1].lower()
    file_name = sys.argv[2].lower()
    if action == "install":
        #fetch package.json from github
        package_json, version = get_github_file_content(repo, file_name, access_token)
        print(package_json)
        # print(version)
        print(INSTALL_DIR)
        install(architecuture, INSTALL_DIR, package_json, file_name, version)    
    elif action == "uninstall":
        file_name = f"{file_name}"
        uninstall(INSTALL_DIR, file_name)
    else:
        print("Invalid action. Use 'install' or 'uninstall'.")
        sys.exit(1)



if __name__ == "__main__":
    main()

