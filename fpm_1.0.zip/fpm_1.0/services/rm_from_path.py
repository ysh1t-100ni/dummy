import subprocess

def remove_path_from_env(new_path):

    # Fetch current PATH from PowerShell
    check_command = '[System.Environment]::GetEnvironmentVariable("PATH", "User")'
    current_path = subprocess.check_output(['powershell', '-Command', check_command], text=True).strip()

    # Split the current PATH into a list of paths
    current_paths = current_path.split(';')


    if not any(new_path in path for path in current_paths):
        # If the new_path is not found in the PATH
        print("Path not found in the env variables")
    else:
        # If the new_path is found in the PATH, remove it
        current_paths = [path for path in current_paths if new_path not in path]
        # Join the paths back into a single string
        full_path = ';'.join(current_paths) + ';'
        
        # Update the PATH variable in the user environment
        ps_command = f'[System.Environment]::SetEnvironmentVariable("PATH", "{full_path}", "User")'
        subprocess.run(['powershell', '-Command', ps_command])
        print(f"Path removed from env variables") 
        
    # for path in current_paths:
    #     if path.__contains__(new_path):
    #         path_to_remove = path
            


    # Check if the new_path is already in the current PATH
    # if new_path.lower() not in [path.lower() for path in current_paths]:
    #     # Append the new_path to the current list of paths
    #     print("Path not found in the env variables")
    # else:
    #     current_paths.remove(new_path)
    #     full_path = ';'.join(current_paths) + ';'
    #     # print(full_path)
    #     ps_command = f'[System.Environment]::SetEnvironmentVariable("PATH", "{full_path}", "User")'
    #     subprocess.run(['powershell', '-Command', ps_command])
    #     print(f"Path removed from env variables")

