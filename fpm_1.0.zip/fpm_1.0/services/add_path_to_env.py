import os
import subprocess
    
def add_to_path(new_path):
    # Command to get the current PATH value in PowerShell
    check_command = '[System.Environment]::GetEnvironmentVariable("PATH", "User")'
    # Run the command to fetch the current PATH
    current_path = subprocess.check_output(['powershell', '-Command', check_command], text=True).strip()
    full_path = current_path + f"{new_path};"
    # subprocess.run(["setx", "PATH", full_path])
    
    ps_command = f'[System.Environment]::SetEnvironmentVariable("PATH", "{full_path}", "User")'
    subprocess.run(['powershell', '-Command', ps_command])
    print(f"Path {new_path} added to user environment variables.")


# def add_to_path(new_path):
#     ps_command = f'[System.Environment]::SetEnvironmentVariable("PATH", "$env:PATH;{new_path}", "User")'
#     subprocess.run(['powershell', '-Command', ps_command])

#     print(f"Path {new_path} added to user environment variables.")