import os

def show_installed_apps():
    # Path to the Scoop directory (adjust if necessary)
    # scoop_path = os.environ.get('fpm', None)
    scoop_path = r"C:\Users\Testing laptop\fpm"
    print(scoop_path)
    
    if not scoop_path:
        print("SCOOP environment variable is not set.")
        return

    # If the apps are directly inside the scoop folder
    installed_apps_dir = scoop_path

    if not os.path.exists(installed_apps_dir):
        print(f"The specified directory '{installed_apps_dir}' does not exist.")
        return

    # List all directories (installed apps) in the Scoop directory
    try:
        installed_apps = [d for d in os.listdir(installed_apps_dir) 
                          if os.path.isdir(os.path.join(installed_apps_dir, d))]

    except FileNotFoundError as e:
        print(f"Error reading the directory: {e}")
        return

    # Loop through each installed app and get its version (from the version file)
    for app_name in installed_apps:
        app_path = os.path.join(installed_apps_dir, app_name)
        version_file = os.path.join(app_path, 'version')

        if os.path.exists(version_file):
            try:
                with open(version_file, 'r') as vf:
                    app_version = vf.read().strip()
                    print(f"{app_name} ({app_version})")
            except Exception as e:
                print(f"Error reading version for {app_name}: {e}")
        else:
            print(f"Version file not found for {app_name}")

if __name__ == "__main__":
    show_installed_apps()
