import os
import sys
import urllib
import subprocess
from services.add_path_to_env import add_to_path
from utils.verify_hash import verify_hash
from utils.zip_extractor import extract_using_7zip


def install_msi(msi_file_path):
    """
    Installs an MSI package using msiexec.

    Args:
        msi_file_path (str): Path to the .msi file.
    """
    # Check if the MSI file exists
    if not os.path.isfile(msi_file_path):
        print(f"Error: The file {msi_file_path} does not exist.")
        return
    
    # Command to silently install the MSI package
    command = [
        "msiexec",
        "/i", msi_file_path,  # /i specifies installation
        "/quiet",  # Silent installation (no UI)
        "/norestart"  # Do not restart after installation
    ]
    
    try:
        # Run the msiexec command
        subprocess.run(command, check=True)
        print(f"Installation of {msi_file_path} completed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error during installation: {e}")

def download_package(PACKAGE_INSTALL_DIRECTORY, arch, package_json, version):
    url= package_json[arch]["url"]
    print(f"Downloading from {url}...")

    if url.endswith(".msi"):
        print('i am in msi ---------------------------------------------')
        msi_path = os.path.join(PACKAGE_INSTALL_DIRECTORY, package_json[arch]["url"].split("/")[-1])
        urllib.request.urlretrieve(url, msi_path)
        install_msi(msi_path)
    elif url.endswith(".exe"):
        print('i am in exe ---------------------------------------------')
        exe_path = os.path.join(PACKAGE_INSTALL_DIRECTORY, package_json[arch]["url"].split("/")[-1])
        urllib.request.urlretrieve(url, exe_path)
        installer_file = url.split('/')[-1]

        installer = os.path.join(PACKAGE_INSTALL_DIRECTORY, installer_file)

        command = ['7z', "x", installer, f"-o{PACKAGE_INSTALL_DIRECTORY}"]

        try:
            subprocess.run(command, check=True)
            print(f"Extraction successful to: {PACKAGE_INSTALL_DIRECTORY}")
        except subprocess.CalledProcessError as e:
            print(f"Error extracting setup.exe: {e}")
        # install_msi(msi_path)
        # result = subprocess.run(['dir', PACKAGE_INSTALL_DIRECTORY, '/b'], capture_output=True, text=True, shell=True)

        # Split the result into a list of file names
        # files = result.stdout.splitlines()
        # print(files)
        # installer_file = url.split('/')[-1]
        # # install_command = ["runas", "/user:Administrator", PACKAGE_INSTALL_DIRECTORY, installer_file, "/S"]
        # # print(installer_file)
        # print(PACKAGE_INSTALL_DIRECTORY)
        # installer = os.path.join(PACKAGE_INSTALL_DIRECTORY, installer_file)
        # install_command = [installer, f"TARGETDIR=f{PACKAGE_INSTALL_DIRECTORY}" "/S", '/quiet']  # /S flag typically for silent installation
        # subprocess.run(install_command, check=True, shell=True)
    else:
        zip_file = os.path.join(PACKAGE_INSTALL_DIRECTORY, package_json[arch]["url"].split("/")[-1])
        urllib.request.urlretrieve(url, zip_file)

        # Verify the hash of the downloaded zip file
        if not verify_hash(zip_file, package_json[arch]['hash']):
            print("Hash verification failed! The downloaded file might be corrupted.")
            os.remove(zip_file)
            sys.exit(1)

        print("Hash verified successfully!")
        pre_install_script = package_json.get("pre_install")
        if pre_install_script:
            print('-----------i am running pre installer------------------')
            subprocess.run(pre_install_script, shell=True, check=True, cwd=PACKAGE_INSTALL_DIRECTORY)

        # Extract using 7-Zip
        extract_using_7zip(PACKAGE_INSTALL_DIRECTORY, zip_file)

        os.remove(zip_file)  # Cleanup the zip file after extraction

        base_filename = os.path.splitext(zip_file.split("/")[-1])[0]
        # new_folder_name = zip_file.split("/")[-1].split("-")[0]
        # new_folder_name = os.path.join(INSTALL_DIR, new_folder_name)
        new_folder_name = os.path.join(PACKAGE_INSTALL_DIRECTORY, version)
        os.rename(base_filename, new_folder_name)
        path_to_add = os.path.join(PACKAGE_INSTALL_DIRECTORY, version)
        print(path_to_add)

        add_to_path(path_to_add)