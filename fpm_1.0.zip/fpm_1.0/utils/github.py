import requests
import base64
import json

def get_github_file_content(repo, file_name, access_token=None):
    # Construct the API URL
    url = f"https://api.github.com/repos/ScoopInstaller/{repo}/contents/bucket/{file_name}.json"
    print(url)
    
    # Set the headers for authentication if a token is provided
    headers = {}
    if access_token:
        headers["Authorization"] = f"token {access_token}"
    
    # Make the API request
    response = requests.get(url, headers=headers)

    # Check if the request was successful
    if response.status_code == 200:
        data = response.json()
        
        # Decode the base64 content
        file_content = base64.b64decode(data['content']).decode('utf-8')
        file_content = json.loads(file_content)
        # print(type(file_content))
        return file_content["architecture"], file_content["version"]
    else:
        return f"Error: {response.status_code} - {response.text}"
    
