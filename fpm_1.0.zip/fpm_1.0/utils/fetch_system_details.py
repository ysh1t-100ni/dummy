import platform

def get_architecture():
    arch = platform.architecture()[0]
    return arch

