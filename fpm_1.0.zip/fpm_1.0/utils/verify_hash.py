# import hashlib

# def verify_hash(file_path, expected_hash):
#     sha256_hash = hashlib.sha256()
#     with open(file_path, 'rb') as f:
#         while chunk := f.read(8192):
#             sha256_hash.update(chunk)
#     return sha256_hash.hexdigest() == expected_hash

# import hashlib

# def verify_hash(file_path, expected_hash, hash_algorithm='sha256'):
#     # Choose the appropriate hash algorithm
#     if hash_algorithm == 'md5':
#         hash_obj = hashlib.md5()
#     elif hash_algorithm == 'sha256':
#         hash_obj = hashlib.sha256()
#     elif hash_algorithm == 'sha512':
#         hash_obj = hashlib.sha512()
#     else:
#         raise ValueError(f"Unsupported hash algorithm: {hash_algorithm}")
    
#     # Read the file and update the hash object
#     with open(file_path, 'rb') as f:
#         while chunk := f.read(8192):
#             hash_obj.update(chunk)
    
#     # Return whether the computed hash matches the expected hash
#     return hash_obj.hexdigest() == expected_hash


import hashlib

def verify_hash(file_path, expected_hash):
    # Check if the hash is prefixed with 'md5:', 'sha256:', or 'sha512:'
    if expected_hash.startswith("md5:"):
        expected_hash_value = expected_hash[4:]  # Remove the 'md5:' prefix
        hash_function = hashlib.md5()
    elif expected_hash.startswith("sha256:"):
        expected_hash_value = expected_hash[7:]  # Remove the 'sha256:' prefix
        hash_function = hashlib.sha256()
    elif expected_hash.startswith("sha512:"):
        expected_hash_value = expected_hash[7:]  # Remove the 'sha512:' prefix
        hash_function = hashlib.sha512()
    else:
        raise ValueError("Unsupported hash type in expected hash string.")

    # Read file and compute the hash
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            hash_function.update(chunk)
    
    # Compare the computed hash with the expected hash
    return hash_function.hexdigest() == expected_hash_value

