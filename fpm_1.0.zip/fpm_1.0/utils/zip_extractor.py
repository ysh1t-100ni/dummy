import sys
import subprocess

def extract_using_7zip(INSTALL_DIR, zip_file):
    print(f"Extracting {zip_file} using 7-Zip...")
    try:
        subprocess.run(['7z', 'x', zip_file, f'-o{INSTALL_DIR}', '-y'], check=True)
        print("Extraction successful!")
    except subprocess.CalledProcessError as e:
        print(f"Error during extraction: {e}")
        sys.exit(1)
