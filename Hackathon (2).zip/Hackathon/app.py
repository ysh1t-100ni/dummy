from flask import Flask, render_template, request, jsonify, send_file
import random
import csv
import io

app = Flask(__name__)

# Dummy database of market funds
funds = {
    "MKTF001": {"name": "Global Equity Fund", "current_status": "Active"},
    "MKTF002": {"name": "Bond Market Fund", "current_status": "Pending"},
    "MKTF003": {"name": "Emerging Markets Fund", "current_status": "Active"},
    "MKTF004": {"name": "Technology Sector Fund", "current_status": "Inactive"},
    "MKTF005": {"name": "Real Estate Investment Fund", "current_status": "Active"},
}

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/get_fund_info', methods=['POST'])
def get_fund_info():
    input_value = request.form['input_value']
    return jsonify(get_fund_data(input_value))

@app.route('/process_file', methods=['POST'])
def process_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file:
        fund_codes = file.read().decode('utf-8').splitlines()
        results = [get_fund_data(code) for code in fund_codes]
        
        # Create CSV file
        csv_file = io.StringIO()
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(['fundCode', 'Name', 'status'])
        for code, result in zip(fund_codes, results):
            csv_writer.writerow([code, result['name'], result['current_status']])
        print('-------------')
        print(results)
        print(csv_file)
        
        csv_file.seek(0)
        return send_file(
            io.BytesIO(csv_file.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            attachment_filename='fund_results.csv'
        )

def get_fund_data(input_value):
    if input_value in funds:
        return funds[input_value]
    elif input_value.lower() == "random":
        return random.choice(list(funds.values()))
    else:
        return {
            "name": f"New Market Fund {input_value}",
            "current_status": random.choice(["Active", "Pending", "Inactive"])
        }

if __name__ == '__main__':
    app.run(debug=True)

