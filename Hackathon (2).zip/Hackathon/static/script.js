document.addEventListener("DOMContentLoaded", () => {
  const radioButtons = document.querySelectorAll('input[name="inputType"]')
  radioButtons.forEach((radio) => {
    radio.addEventListener("change", toggleInputType)
  })
})

function toggleInputType() {
  const singleContainer = document.getElementById("singleInputContainer")
  const bulkContainer = document.getElementById("bulkInputContainer")
  if (this.value === "single") {
    singleContainer.classList.remove("hidden")
    bulkContainer.classList.add("hidden")
  } else {
    singleContainer.classList.add("hidden")
    bulkContainer.classList.remove("hidden")
  }
}

function getFundInfo() {
  const input = document.getElementById("fundInput").value
  fetch("/get_fund_info", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `input_value=${encodeURIComponent(input)}`,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        alert("Error: " + data.error)
      } else {
        document.getElementById("fundName").textContent = data.name
        document.getElementById("fundStatus").textContent = data.current_status
        document.getElementById("resultContainer").classList.remove("hidden")

        const summary = `The fund ${data.name} has current status ${data.current_status}`
        document.getElementById("summary").textContent = summary
        document.getElementById("summaryContainer").classList.remove("hidden")
        document.getElementById("csvDownloadContainer").classList.add("hidden")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("An error occurred. Please try again.")
    })
}

function copyToClipboard(elementId) {
  const element = document.getElementById(elementId)
  const text = element.textContent
  navigator.clipboard
    .writeText(text)
    .then(() => {
      const copyBtn = element.nextElementSibling
      const copyText = copyBtn.querySelector(".copy-text")
      copyText.textContent = "Copied!"
      setTimeout(() => {
        copyText.textContent = "Copy"
      }, 2000)
    })
    .catch((err) => {
      console.error("Failed to copy: ", err)
    })
}

function uploadFile() {
  const fileInput = document.getElementById("fileInput")
  if (!fileInput.files.length) {
    alert("Please select a file to upload.")
    return
  }

  const formData = new FormData()
  formData.append("file", fileInput.files[0])

  fetch("/process_file", {
    method: "POST",
    body: formData,
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok")
      }
      return response.blob()
    })
    .then((blob) => {
      const url = window.URL.createObjectURL(blob)
      const a = document.getElementById("csvDownloadLink")
      a.href = url
      document.getElementById("csvDownloadContainer").classList.remove("hidden")
      document.getElementById("resultContainer").classList.add("hidden")
      document.getElementById("summaryContainer").classList.remove("hidden")
      document.getElementById("summary").textContent =
        "File processed successfully. Click the button below to download the CSV file."
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("An error occurred while processing the file. Please try again.")
    })
}

