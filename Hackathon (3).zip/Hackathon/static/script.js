let excelUploaded = false

document.addEventListener("DOMContentLoaded", () => {
  const radioButtons = document.querySelectorAll('input[name="inputType"]')
  radioButtons.forEach((radio) => {
    radio.addEventListener("change", toggleInputType)
  })
})

function toggleInputType() {
  const singleContainer = document.getElementById("singleInputContainer")
  const bulkContainer = document.getElementById("bulkInputContainer")

  if (this.value === "single") {
    singleContainer.classList.remove("hidden")
    bulkContainer.classList.add("hidden")
  } else {
    singleContainer.classList.add("hidden")
    bulkContainer.classList.remove("hidden")
  }
}

function uploadExcel() {
  const fileInput = document.getElementById("excelInput")
  if (!fileInput.files.length) {
    alert("Please select an Excel file.")
    return
  }

  const formData = new FormData()
  formData.append("file", fileInput.files[0])

  fetch("/upload_excel", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      const statusDiv = document.getElementById("excelStatus")
      if (data.error) {
        statusDiv.textContent = "Error: " + data.error
        statusDiv.className = "status-message error"
        excelUploaded = false
      } else {
        statusDiv.textContent = data.message
        statusDiv.className = "status-message success"
        excelUploaded = true
        // Enable search and bulk process buttons
        document.getElementById("searchBtn").disabled = false
        document.getElementById("bulkBtn").disabled = false
      }
      statusDiv.classList.remove("hidden")
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("An error occurred while uploading the Excel file.")
    })
}

function getFundInfo() {
  if (!excelUploaded) {
    alert("Please upload Excel file first.")
    return
  }

  const input = document.getElementById("fundInput").value
  fetch("/get_fund_info", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `fund_code=${encodeURIComponent(input)}`,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        alert(data.error)
      } else {
        displayFundInfo(data.data)
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("An error occurred. Please try again.")
    })
}

function displayFundInfo(data) {
  document.getElementById("fundCode").textContent = data["fund code"]
  document.getElementById("fundName").textContent = data["fund name"]
  document.getElementById("invstCompany").textContent = data["invst_compnay"]
  document.getElementById("subCompany").textContent = data["sub compnay"]
  document.getElementById("resultContainer").classList.remove("hidden")
}

function processBulkFile() {
  if (!excelUploaded) {
    alert("Please upload Excel file first.")
    return
  }

  const fileInput = document.getElementById("fileInput")
  if (!fileInput.files.length) {
    alert("Please select a text file with fund codes.")
    return
  }

  const formData = new FormData()
  formData.append("file", fileInput.files[0])

  fetch("/process_bulk", {
    method: "POST",
    body: formData,
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok")
      }
      return response.blob()
    })
    .then((blob) => {
      const url = window.URL.createObjectURL(blob)
      const a = document.getElementById("csvDownloadLink")
      a.href = url
      document.getElementById("csvDownloadContainer").classList.remove("hidden")
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("An error occurred while processing the file.")
    })
}

function copyToClipboard(elementId) {
  const element = document.getElementById(elementId)
  const text = element.textContent
  navigator.clipboard
    .writeText(text)
    .then(() => {
      const copyBtn = element.nextElementSibling
      const copyText = copyBtn.querySelector(".copy-text")
      copyText.textContent = "Copied!"
      setTimeout(() => {
        copyText.textContent = "Copy"
      }, 2000)
    })
    .catch((err) => {
      console.error("Failed to copy: ", err)
    })
}

