from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import json
import io

app = Flask(__name__)

# Global variable to store Excel data
excel_data = None

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload_excel', methods=['POST'])
def upload_excel():
    global excel_data
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if not file.filename.endswith(('.xls', '.xlsx')):
        return jsonify({'error': 'Invalid file format. Please upload an Excel file.'})
    
    try:
        # Read Excel file
        df = pd.read_excel(file)
        # Convert column names to lowercase and strip whitespace
        df.columns = df.columns.str.lower().str.strip()
        # Store DataFrame as dictionary
        excel_data = df.to_dict('records')
        return jsonify({'success': True, 'message': 'Excel file uploaded successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/get_fund_info', methods=['POST'])
def get_fund_info():
    global excel_data
    if excel_data is None:
        return jsonify({'error': 'Please upload Excel file first'})
    
    fund_code = request.form['fund_code']
    # Search for fund in excel_data
    fund = next((item for item in excel_data if str(item['fund_id']).lower() == fund_code.lower()), None)
    
    if fund:
        return jsonify({
            'success': True,
            'data': fund
        })
    else:
        return jsonify({'error': f'Fund code {fund_code} not found'})

@app.route('/process_bulk', methods=['POST'])
def process_bulk():
    global excel_data
    if excel_data is None:
        return jsonify({'error': 'Please upload Excel file first'})
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    try:
        # Read fund codes from uploaded text file
        fund_codes = file.read().decode('utf-8').splitlines()
        results = []
        
        # Search for each fund code in excel_data
        for code in fund_codes:
            fund = next((item for item in excel_data if str(item['fund code']).lower() == code.lower()), None)
            if fund:
                results.append(fund)
        
        # Create CSV file
        output = io.StringIO()
        if results:
            writer = csv.DictWriter(output, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
        
        output.seek(0)
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            attachment_filename='fund_results.csv'
        )
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)

