import random
import json

class QuizManager:
    def __init__(self):
        print("------------------------------------------")
        with open('data.json', 'r') as file:
            self.all_questions = json.load(file)
            # self.all_questions = json.dumps(self.all_questions)
        print(type(self.all_questions))
        # return self.all_questions
    #     self.reset_quiz()

    # def reset_quiz(self):
    #     self.current_questions = random.sample(self.all_questions, 5)
    #     self.current_question_index = 0
    #     self.score = 0
    #     self.correct_answers = 0

    def get_next_question(self):
        # if self.current_question_index < len(self.current_questions):
        # question = self.current_questions[self.current_question_index]
        question = random.sample(self.all_questions, 5)
        # self.current_question_index += 1
        return {
            'question': question['question'],
            'options': question['options']
        }
        # return None

    def check_answer(self, user_answer):
        current_question = self.current_questions[self.current_question_index - 1]
        correct_answer = current_question['correct_answer']
        is_correct = user_answer == correct_answer
        if is_correct:
            self.score += 1
            self.correct_answers += 1
        return {
            'is_correct': is_correct,
            'correct_answer': correct_answer,
            'score': self.score,
            'is_last_question': self.current_question_index == len(self.current_questions)
        }

