# from flask import Flask, render_template, request, jsonify, redirect, url_for, session
# from flask_wtf import CSRFProtect
# from quiz_manager import QuizManager
# import csv
# from operator import itemgetter

# app = Flask(__name__)
# app.config['SECRET_KEY'] = 'your-secret-key'  # Change this to a random secret key
# csrf = CSRFProtect(app)

# def check_user(aid):
#     with open('users_data.txt', 'r') as file:
#         reader = csv.reader(file)
#         for row in reader:
#             if row[1] == aid:
#                 return True
#     return False

# def save_user(name, aid, score):
#     with open('users_data.txt', 'a', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerow([name, aid, score])

# def get_top_performers(limit=10):
#     with open('users_data.txt', 'r') as file:
#         reader = csv.reader(file)
#         performers = sorted(reader, key=lambda x: int(x[2]), reverse=True)
#     return performers[:limit]

# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         name = request.form.get('name')
#         aid = request.form.get('aid')
        
#         if check_user(aid):
#             return render_template('index.html', error="You have already participated in the quiz.")
        
#         session['name'] = name
#         session['aid'] = aid
#         print('----------------------')
#         session['quiz_manager'] = QuizManager()
#         print('----------------------')
#         print(session['quiz_manager'])
#         return redirect(url_for('quiz'))
    
#     return render_template('index.html')

# @app.route('/quiz', methods=['GET', 'POST'])
# def quiz():
#     print('I am here -------------------------------------------------')
#     if 'name' not in session or 'aid' not in session or 'quiz_manager' not in session:
#         return redirect(url_for('index'))
#     quiz_manager = session['quiz_manager']
    
#     if request.method == 'POST':
#         answer = request.form.get('answer')
#         result = quiz_manager.check_answer(answer)
#         session['quiz_manager'] = quiz_manager
#         if result['is_last_question']:
#             return jsonify({'redirect': url_for('score')})
#         return jsonify(result)
    
#     question_data = quiz_manager.get_next_question()
#     if question_data is None:
#         return redirect(url_for('score'))
    
#     return render_template('quiz.html', question=question_data['question'], options=question_data['options'])

# @app.route('/score')
# def score():
#     if 'name' not in session or 'aid' not in session or 'quiz_manager' not in session:
#         return redirect(url_for('index'))
    
#     name = session['name']
#     aid = session['aid']
#     quiz_manager = session['quiz_manager']
#     final_score = quiz_manager.score
#     correct_answers = quiz_manager.correct_answers
#     total_questions = len(quiz_manager.current_questions)
    
#     save_user(name, aid, final_score)
    
#     # Clear the session
#     session.clear()
    
#     return render_template('score.html', name=name, aid=aid, score=final_score, 
#                            correct_answers=correct_answers, total_questions=total_questions)

# @app.route('/dashboard')
# def dashboard():
#     top_performers = get_top_performers()
#     return render_template('dashboard.html', performers=top_performers)

# if __name__ == '__main__':
#     app.run(debug=True)


from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from flask_wtf import CSRFProtect
from quiz_manager import QuizManager
import csv
from operator import itemgetter

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # Change this to a random secret key
csrf = CSRFProtect(app)

def check_user(aid):
    with open('users_data.txt', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[1] == aid:
                return True
    return False

def save_user(name, aid, score):
    with open('users_data.txt', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, aid, score])

def get_top_performers(limit=10):
    with open('users_data.txt', 'r') as file:
        reader = csv.reader(file)
        performers = sorted(reader, key=lambda x: int(x[2]), reverse=True)
    return performers[:limit]

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form.get('name')
        aid = request.form.get('aid')
        
        if check_user(aid):
            return render_template('index.html', error="You have already participated in the quiz.")
        
        session['name'] = name
        session['aid'] = aid
        
        # Initialize quiz manager and get random questions
        quiz_manager = QuizManager()
        session['current_questions'] = quiz_manager.get_random_questions()
        session['current_question_index'] = 0
        session['score'] = 0
        
        return redirect(url_for('quiz'))
    
    return render_template('index.html')

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if 'name' not in session or 'aid' not in session or 'current_questions' not in session:
        return redirect(url_for('index'))
    
    # Retrieve quiz data from the session
    current_questions = session['current_questions']
    current_question_index = session['current_question_index']
    score = session['score']
    
    if request.method == 'POST':
        answer = request.form.get('answer')
        
        # Get the current question and check if the answer is correct
        current_question = current_questions[current_question_index]
        correct_answer = current_question['correct_answer']
        is_correct = answer == correct_answer
        if is_correct:
            score += 1
        
        # Update session data
        session['score'] = score
        session['current_question_index'] = current_question_index + 1
        
        is_last_question = current_question_index == len(current_questions) - 1
        
        if is_last_question:
            return jsonify({'redirect': url_for('score')})
        
        return jsonify({
            'is_correct': is_correct,
            'correct_answer': correct_answer,
            'score': score,
            'is_last_question': is_last_question
        })
    
    # If there are more questions to show
    if current_question_index < len(current_questions):
        question = current_questions[current_question_index]
        return render_template('quiz.html', question=question['question'], options=question['options'])
    
    return redirect(url_for('score'))

@app.route('/score')
def score():
    if 'name' not in session or 'aid' not in session or 'score' not in session:
        return redirect(url_for('index'))
    
    name = session['name']
    aid = session['aid']
    score = session['score']
    correct_answers = score  # Assuming score corresponds to correct answers for simplicity
    total_questions = len(session['current_questions'])
    
    save_user(name, aid, score)
    
    # Clear the session
    session.clear()
    
    return render_template('score.html', name=name, aid=aid, score=score, 
                           correct_answers=correct_answers, total_questions=total_questions)

@app.route('/dashboard')
def dashboard():
    top_performers = get_top_performers()
    return render_template('dashboard.html', performers=top_performers)

if __name__ == '__main__':
    app.run(debug=True)
