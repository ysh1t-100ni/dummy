function getFundInfo() {
    const input = document.getElementById("fundInput").value
    fetch("/get_fund_info", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `input_value=${encodeURIComponent(input)}`,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.error) {
          alert("Error: " + data.error)
        } else {
          document.getElementById("fundName").textContent = data.name
          document.getElementById("fundStatus").textContent = data.current_status
          document.getElementById("resultContainer").classList.remove("hidden")
  
          const summary = `The fund ${data.name} has current status ${data.current_status}`
          document.getElementById("summary").textContent = summary
          document.getElementById("summaryContainer").classList.remove("hidden")
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("An error occurred. Please try again.")
      })
  }
  
  function copyToClipboard(elementId) {
    const element = document.getElementById(elementId)
    const text = element.textContent
    navigator.clipboard
      .writeText(text)
      .then(() => {
        const copyBtn = element.nextElementSibling
        const copyText = copyBtn.querySelector(".copy-text")
        copyText.textContent = "Copied!"
        setTimeout(() => {
          copyText.textContent = "Copy"
        }, 2000)
      })
      .catch((err) => {
        console.error("Failed to copy: ", err)
      })
  }
  
  