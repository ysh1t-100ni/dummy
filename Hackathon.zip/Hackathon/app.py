from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Dummy database of funds
funds = {
    "SPCE001": {"name": "Galactic Ventures Fund", "current_status": "Active"},
    "MARS002": {"name": "Red Planet Exploration Fund", "current_status": "Pending"},
    "MOON003": {"name": "Lunar Industries Fund", "current_status": "Active"},
    "NEPT004": {"name": "Deep Space Mining Fund", "current_status": "Inactive"},
    "SATX005": {"name": "Satellite Communications Fund", "current_status": "Active"},
}

@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/get_fund_info', methods=['POST'])
def get_fund_info():
    input_value = request.form['input_value']

    if input_value in funds:
        return jsonify(funds[input_value])
    else:
        api_url = f"https://api.fund.com/fund/{input_value}"
        
        try:
            response = requests.get(api_url)
            data = response.json()
            return jsonify({
                'name': data['name'],
                'status': data['current_status']
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)

